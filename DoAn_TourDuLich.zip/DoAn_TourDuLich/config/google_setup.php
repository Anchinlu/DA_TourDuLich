<?php
require_once 'vendor/autoload.php';

$google_client_id = '195228555998-uvdt8grleiq8t8e01npiolg1afds5gq3.apps.googleusercontent.com'; 

$google_client_secret = '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';
// ---------------------

$google_redirect_url = 'http://localhost:8080/DoAn_TourDuLich/google_callback.php';

$client = new Google_Client();
$client->setClientId($google_client_id);
$client->setClientSecret($google_client_secret);
$client->setRedirectUri($google_redirect_url);
$client->addScope('email');
$client->addScope('profile');
?>