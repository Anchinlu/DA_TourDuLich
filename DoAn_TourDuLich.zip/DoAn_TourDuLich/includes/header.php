<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$isLoggedIn = isset($_SESSION['user_id']);
$avatarUrl = 'assets/images/default-avatar.png'; // Ảnh mặc định
$userName = 'Khách';

if ($isLoggedIn) {
    $userName = $_SESSION['fullname'];
    $userAvatar = $_SESSION['avatar'];

    // Xử lý link ảnh
    if (!empty($userAvatar)) {
        if (strpos($userAvatar, 'http') === 0) {
            $avatarUrl = $userAvatar;
        } else {
            $avatarUrl = 'uploads/avatars/' . $userAvatar;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chinliu Tour - Trải Nghiệm Khác Biệt</title>
    <meta name="referrer" content="no-referrer"> <link rel="stylesheet" href="assets/css/home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<div class="top-bar">
    <div class="container flex-between">
        <div class="contact-info">
            <span><i class="fas fa-map-marker-alt"></i> Q.Tân Bình, TP.HCM</span>
            <span><i class="fas fa-envelope"></i> info@mona.global</span>
        </div>
        <div class="social-icons" style="display:flex; gap:15px;">
            <span style="margin-right:10px;">ĐẶT TOUR NGAY</span>
            <a href="#" style="color:white;"><i class="fab fa-facebook-f"></i></a>
            <a href="#" style="color:white;"><i class="fab fa-instagram"></i></a>
        </div>
    </div>
</div>

<nav class="navbar">
    <div class="container flex-between">
        <a href="index.php" class="logo">Chinliu <span>Tour</span></a>
        
        <ul class="nav-menu">
            <li><a href="index.php">Trang chủ</a></li>
            <li><a href="#">Giới thiệu</a></li>
            <li><a href="#">Tours</a></li>
            <li><a href="#">Tin tức</a></li>
            <li><a href="#">Liên hệ</a></li>
        </ul>

        <div class="nav-icons">
            <i class="fas fa-search search-icon"></i>
            
            <?php if ($isLoggedIn): ?>
                <div class="user-dropdown">
                    <div class="user-profile">
                        <img src="<?php echo $avatarUrl; ?>" class="avatar-circle" 
                             onerror="this.onerror=null; this.src='assets/images/default-avatar.png';">
                        <span class="user-name-text"><?php echo htmlspecialchars($userName); ?></span>
                    </div>
                    <div class="dropdown-content">
                        <a href="#"><i class="fas fa-history"></i> Lịch sử đặt</a>
                        <a href="logout.php" class="logout-text"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a>
                    </div>
                </div>
            <?php else: ?>
                <a href="login.php" class="btn-primary" style="padding: 8px 20px; font-size: 13px;">ĐĂNG NHẬP</a>
            <?php endif; ?>
        </div>
    </div>
</nav>