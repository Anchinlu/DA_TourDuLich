<footer style="background: #2d3436; color: white; padding: 50px 0; margin-top: 50px; text-align: center;">
        <div class="container">
            <p>&copy; 2025 Mona Tour. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>