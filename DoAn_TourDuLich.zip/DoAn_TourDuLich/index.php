<?php 
include 'includes/header.php'; 
require_once 'config/db_connect.php';

// Lấy 4 tour mới nhất từ CSDL
try {
    $sql = "SELECT * FROM Tour ORDER BY id DESC LIMIT 4";
    $stmt = $db->query($sql);
    $tours = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $tours = []; // Tránh lỗi nếu query fail
}
?>

<section class="hero-section">
    <div class="hero-slideshow">
        <div class="slide active" style="background-image: url('https://images.pexels.com/photos/2422265/pexels-photo-2422265.jpeg?auto=compress&cs=tinysrgb&w=1600');">
            <div class="overlay"></div>
            <div class="container h-100">
                <div class="hero-content">
                    <span class="badge anim-item delay-1">Khám phá thiên nhiên</span>
                    <h1 class="hero-title anim-item delay-2">TRẢI NGHIỆM CUỘC SỐNG <br>TRONG RỪNG</h1>
                    <p class="hero-desc anim-item delay-3">Hòa mình vào thiên nhiên hoang dã, khám phá rừng nguyên sinh.</p>
                    <button class="btn-primary anim-item delay-4">Xem chi tiết</button>
                </div>
            </div>
        </div>
        <div class="slide" style="background-image: url('https://images.pexels.com/photos/1365428/pexels-photo-1365428.jpeg?auto=compress&cs=tinysrgb&w=1600');">
            <div class="overlay"></div>
            <div class="container h-100">
                <div class="hero-content">
                    <span class="badge anim-item delay-1" style="background: #e67e22;">Leo núi & Mạo hiểm</span>
                    <h1 class="hero-title anim-item delay-2">CHINH PHỤC <br>NHỮNG ĐỈNH CAO</h1>
                    <p class="hero-desc anim-item delay-3">Thử thách bản thân với những cung đường trekking tuyệt đẹp.</p>
                    <button class="btn-primary anim-item delay-4">Đặt tour ngay</button>
                </div>
            </div>
        </div>
        <div class="slide" style="background-image: url('https://images.pexels.com/photos/2166553/pexels-photo-2166553.jpeg?auto=compress&cs=tinysrgb&w=1600');">
            <div class="overlay"></div>
            <div class="container h-100">
                <div class="hero-content">
                    <span class="badge anim-item delay-1" style="background: #039be5;">Biển xanh vẫy gọi</span>
                    <h1 class="hero-title anim-item delay-2">THƯ GIÃN <br>BÊN BỜ BIỂN XANH</h1>
                    <p class="hero-desc anim-item delay-3">Tận hưởng kỳ nghỉ dưỡng đẳng cấp tại những bãi biển đẹp nhất.</p>
                    <button class="btn-primary anim-item delay-4">Khám phá ngay</button>
                </div>
            </div>
        </div>
        <div class="slide" style="background-image: url('https://images.pexels.com/photos/1659438/pexels-photo-1659438.jpeg?auto=compress&cs=tinysrgb&w=1600');">
            <div class="overlay"></div>
            <div class="container h-100">
                <div class="hero-content">
                    <span class="badge anim-item delay-1" style="background: #43a047;">Camping & Glamping</span>
                    <h1 class="hero-title anim-item delay-2">ĐÊM NGỦ <br>DƯỚI NGÀN VÌ SAO</h1>
                    <p class="hero-desc anim-item delay-3">Trải nghiệm cắm trại tiện nghi, đốt lửa trại và ngắm sao đêm.</p>
                    <button class="btn-primary anim-item delay-4">Đặt lều ngay</button>
                </div>
            </div>
        </div>
    </div>

    <form action="search.php" method="GET" class="search-box-wrapper anim-item delay-4">
        <div class="search-item">
            <label class="search-label"><i class="fas fa-map-marker-alt"></i> Từ khóa</label>
            <input type="text" name="k" class="search-input" placeholder="Bạn muốn đi đâu?">
        </div>
        <div class="search-item">
            <label class="search-label"><i class="fas fa-route"></i> Danh mục</label>
            <select name="c" class="search-input" style="background:transparent; border:none;">
                <option value="">Tất cả</option>
                <?php
                $cats = $db->query("SELECT * FROM DanhMuc")->fetchAll();
                foreach($cats as $cat) {
                    echo "<option value='".$cat['id']."'>".$cat['TenDanhMuc']."</option>";
                }
                ?>
            </select>
        </div>
        <div class="search-item">
            <label class="search-label"><i class="far fa-calendar-alt"></i> Ngày đi</label>
            <input type="date" name="d" class="search-input">
        </div>
        <div class="search-item">
            <label class="search-label"><i class="far fa-user"></i> Giá tối đa</label>
            <input type="number" name="p" class="search-input" placeholder="Nhập giá..." step="500000">
        </div>
        <div class="search-item">
            <button type="submit" class="search-btn"><i class="fas fa-search"></i> TÌM KIẾM</button>
        </div>
    </form>
</section>

<section class="adventure-section">
    <div class="container">
        <div class="text-center" style="margin-bottom: 50px;">
            <span class="section-tag" style="background:#333; color:var(--accent-orange);">Hoạt động nổi bật</span>
            <h2 class="section-title" style="color:white;">Cảm giác phiêu lưu</h2>
        </div>

        <div class="adventure-wrapper">
            <div class="adv-tabs">
                <div class="adv-tab-item active"><i class="fas fa-campground"></i> Cắm trại</div>
                <div class="adv-tab-item"><i class="fas fa-mountain"></i> Du lịch mạo hiểm</div>
                <div class="adv-tab-item"><i class="fas fa-biking"></i> Đạp xe leo núi</div>
                <div class="adv-tab-item"><i class="fas fa-globe-americas"></i> Khám phá thế giới</div>
                <div class="adv-tab-item"><i class="fas fa-swimmer"></i> Câu cá & bơi lội</div>
                <div class="adv-tab-item"><i class="fas fa-hiking"></i> Đi bộ leo núi</div>
            </div>

            <div class="adv-content">
                <div class="adv-text-block">
                    <i class="fas fa-campground adv-icon-large" style="color: #4CAF50;"></i>
                    <h3 class="adv-title">Cuộc phiêu lưu thực sự và tận hưởng những chuyến đi mơ ước của bạn.</h3>
                    <p class="adv-desc">Chúng tôi đặt trái tim của mình vào việc tạo ra những trải nghiệm phiêu lưu độc đáo, nơi bạn có thể tận hưởng sự kết nối thân thiết với tự nhiên.</p>
                    
                    <div class="skill-box">
                        <div class="skill-info"><span>Khách hàng hài lòng</span><span>90%</span></div>
                        <div class="progress-bg"><div class="progress-bar" style="width: 90%;"></div></div>
                    </div>
                    <div class="skill-box">
                        <div class="skill-info"><span>Đánh giá tích cực</span><span>98%</span></div>
                        <div class="progress-bg"><div class="progress-bar" style="width: 98%;"></div></div>
                    </div>
                </div>

                <div class="adv-image-block">
                    <img src="https://images.pexels.com/photos/2398220/pexels-photo-2398220.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Camping">
                </div>
            </div>
        </div>
    </div>
</section>

<div class="cta-strip">
    <div class="container">
        <div class="cta-content">
            <div class="cta-text">
                <i class="fas fa-globe-asia cta-icon"></i>
                <div>
                    <span style="font-size: 12px; text-transform:uppercase; opacity:0.8;">Phiêu lưu độc đáo</span>
                    <h3>Sẵn sàng phiêu lưu và tận hưởng thiên nhiên</h3>
                </div>
            </div>
            <a href="search.php" class="btn-white">Khám phá ngay</a>
        </div>
    </div>
</div>

<section class="section-padding">
    <div class="container">
        <div class="text-center">
            <span class="section-tag">Trải nghiệm tuyệt vời</span>
            <h2 class="section-title">Các địa điểm thú vị</h2>
        </div>

        <div class="adventure-grid">
            <?php if (isset($tours) && count($tours) > 0): ?>
                <?php foreach ($tours as $tour): ?>
                    <a href="tour_detail.php?id=<?php echo $tour['id']; ?>" class="card-adventure">
                        <span class="card-badge">Đặc sắc</span>
                        <?php $imgSrc = !empty($tour['HinhAnh']) ? $tour['HinhAnh'] : 'https://images.pexels.com/photos/2161449/pexels-photo-2161449.jpeg'; ?>
                        <img src="<?php echo $imgSrc; ?>" alt="<?php echo htmlspecialchars($tour['TenTour']); ?>">
                        
                        <div class="card-overlay">
                            <div class="card-rating">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                            </div>
                            <h4 class="card-title"><?php echo htmlspecialchars($tour['TenTour']); ?></h4>
                            <div class="card-meta">
                                <span><i class="fas fa-map-marker-alt"></i> Việt Nam</span>
                                <span style="color: #4dd0e1; font-weight:700;">
                                    <i class="fas fa-tag"></i> <?php echo number_format($tour['Gia'], 0, ',', '.'); ?>đ
                                </span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="text-align:center; grid-column: 1/-1;">Chưa có tour nào.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="section-padding" style="background: #f9f9f9; padding-top: 0;">
    <div class="container">
        <div class="service-grid">
            <div class="service-card">
                <div class="srv-icon"><i class="fas fa-map-marked-alt"></i></div>
                <div class="srv-content">
                    <h4>Chuyến đi tùy chỉnh</h4>
                    <p>Có thể chọn địa điểm, thời gian và hoạt động mà bạn muốn tham gia.</p>
                </div>
            </div>
            <div class="service-card">
                <div class="srv-icon"><i class="fas fa-user-shield"></i></div>
                <div class="srv-content">
                    <h4>Hướng dẫn viên chuyên nghiệp</h4>
                    <p>Đội ngũ hướng dẫn viên có kiến thức sâu rộng về văn hóa địa phương.</p>
                </div>
            </div>
            <div class="service-card">
                <div class="srv-icon"><i class="far fa-star"></i></div>
                <div class="srv-content">
                    <h4>Chất lượng dịch vụ cao</h4>
                    <p>Chúng tôi đảm bảo rằng mọi khía cạnh đều được chăm sóc tận tâm.</p>
                </div>
            </div>
            <div class="service-card">
                <div class="srv-icon"><i class="fas fa-globe"></i></div>
                <div class="srv-content">
                    <h4>Địa điểm đa dạng</h4>
                    <p>Cung cấp các địa điểm du lịch hấp dẫn trên khắp thế giới phù hợp sở thích.</p>
                </div>
            </div>
            <div class="service-card">
                <div class="srv-icon"><i class="fas fa-camera-retro"></i></div>
                <div class="srv-content">
                    <h4>Trải nghiệm độc đáo</h4>
                    <p>Không chỉ đưa bạn đến điểm du lịch phổ biến mà còn mang đến trải nghiệm khác biệt.</p>
                </div>
            </div>
            <div class="service-card">
                <div class="srv-icon"><i class="fas fa-headset"></i></div>
                <div class="srv-content">
                    <h4>Hỗ trợ dịch vụ 24/7</h4>
                    <p>Đội ngũ chăm sóc khách hàng luôn sẵn sàng giải đáp mọi thắc mắc của bạn.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="assets/js/slider.js"></script>
<?php include 'includes/footer.php'; ?>