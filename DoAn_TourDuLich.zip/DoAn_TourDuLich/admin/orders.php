<?php include 'includes/header.php'; 

// --- XỬ LÝ CẬP NHẬT TRẠNG THÁI ---
if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = $_GET['id'];
    $status = $_GET['status'];
    
    // Chỉ cho phép các trạng thái hợp lệ
    if (in_array($status, ['Đã xác nhận', 'Đã hủy', 'Chờ xử lý'])) {
        $stmt = $db->prepare("UPDATE DonDatTour SET TrangThai = ? WHERE id = ?");
        $stmt->execute([$status, $id]);
        echo "<script>window.location='orders.php';</script>";
    }
}

// --- LẤY DANH SÁCH ĐƠN HÀNG ---
// Kết nối 3 bảng: DonDatTour, NguoiDung, Tour
$sql = "SELECT d.*, u.TenDayDu, u.TenDangNhap, t.TenTour 
        FROM DonDatTour d
        JOIN NguoiDung u ON d.idNguoiDung = u.id
        JOIN Tour t ON d.idTour = t.id
        ORDER BY d.NgayDat DESC";
$orders = $db->query($sql)->fetchAll();
?>

<div class="card">
    <h2>Quản lý Đơn Đặt Tour</h2>
    <p style="color:#666; margin-bottom:20px;">Danh sách các yêu cầu đặt tour từ khách hàng.</p>

    <table>
        <thead>
            <tr>
                <th>Mã Đơn</th>
                <th>Khách hàng</th>
                <th>Tour & Ngày đi</th>
                <th>Số lượng</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orders as $order): ?>
            <tr>
                <td><strong>#<?php echo $order['id']; ?></strong></td>
                <td>
                    <strong><?php echo htmlspecialchars($order['TenDayDu']); ?></strong><br>
                    <small style="color:#888"><?php echo htmlspecialchars($order['TenDangNhap']); ?></small>
                </td>
                <td>
                    <span style="color:#00897B; font-weight:600;"><?php echo htmlspecialchars($order['TenTour']); ?></span><br>
                    <small><i class="far fa-calendar-alt"></i> <?php echo date('d/m/Y', strtotime($order['NgayKhoiHanh'])); ?></small>
                </td>
                <td>
                    <?php echo $order['SoNguoiLon']; ?> Lớn<br>
                    <?php echo $order['SoTreEm']; ?> Trẻ
                </td>
                <td style="color:#d32f2f; font-weight:bold;">
                    <?php echo number_format($order['TongGia'], 0, ',', '.'); ?>đ
                </td>
                <td>
                    <?php 
                        $stt = $order['TrangThai'];
                        $color = '#f59e0b'; // Vàng (Chờ)
                        if($stt == 'Đã xác nhận') $color = '#10b981'; // Xanh (OK)
                        if($stt == 'Đã hủy') $color = '#ef4444'; // Đỏ (Hủy)
                    ?>
                    <span class="status-badge" style="background:<?php echo $color; ?>; color:white;">
                        <?php echo $stt; ?>
                    </span>
                </td>
                <td>
                    <?php if ($order['TrangThai'] == 'Chờ xử lý'): ?>
                        <a href="orders.php?id=<?php echo $order['id']; ?>&status=Đã xác nhận" 
                           class="btn btn-sm btn-primary" title="Xác nhận đơn">
                           <i class="fas fa-check"></i>
                        </a>
                        <a href="orders.php?id=<?php echo $order['id']; ?>&status=Đã hủy" 
                           class="btn btn-sm btn-danger" title="Hủy đơn"
                           onclick="return confirm('Bạn muốn hủy đơn hàng này?');">
                           <i class="fas fa-times"></i>
                        </a>
                    <?php else: ?>
                        <span style="font-size:12px; color:#999;">Đã xử lý</span>
                        <a href="orders.php?id=<?php echo $order['id']; ?>&status=Chờ xử lý" style="color:#aaa; margin-left:5px;"><i class="fas fa-undo"></i></a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include 'includes/footer.php'; ?>