<div class="sidebar">
    <div class="sidebar-brand">LOCY <span>Admin</span></div>
    <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fas fa-home"></i> Dashboard</a></li>
        <li><a href="users.php" class="active"><i class="fas fa-users"></i> Quản lý Người dùng</a></li>
        <li><a href="categories.php"><i class="fas fa-list"></i> Quản lý Danh mục</a></li>
        <li><a href="tours.php"><i class="fas fa-map-marked-alt"></i> Quản lý Tour</a></li>
        <li><a href="orders.php"><i class="fas fa-shopping-cart"></i> Quản lý Đơn hàng</a></li>
        <li><a href="../index.php" target="_blank"><i class="fas fa-globe"></i> Xem Website</a></li>
        <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a></li>
    </ul>
</div>