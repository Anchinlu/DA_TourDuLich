<?php 
include 'includes/header.php'; 
require_once 'config/db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Lấy danh sách đơn hàng của user này
$sql = "SELECT d.*, t.TenTour, t.HinhAnh 
        FROM DonDatTour d 
        JOIN Tour t ON d.idTour = t.id 
        WHERE d.idNguoiDung = ? 
        ORDER BY d.NgayDat DESC";
$stmt = $db->prepare($sql);
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll();
?>

<div class="container section-padding">
    <h2 class="section-title text-center">Lịch Sử Chuyến Đi</h2>

    <div style="max-width: 900px; margin: 0 auto;">
        <?php if (count($orders) > 0): ?>
            <?php foreach ($orders as $item): ?>
                <div style="display:flex; gap:20px; background:white; padding:20px; border-radius:10px; margin-bottom:20px; box-shadow:0 2px 10px rgba(0,0,0,0.05); border:1px solid #eee; align-items:center;">
                    <img src="<?php echo $item['HinhAnh']; ?>" style="width:120px; height:80px; object-fit:cover; border-radius:6px;">
                    
                    <div style="flex:1;">
                        <h4 style="margin-bottom:5px; font-size:18px;"><?php echo htmlspecialchars($item['TenTour']); ?></h4>
                        <p style="font-size:13px; color:#666; margin-bottom:5px;">
                            <i class="far fa-calendar-alt"></i> Khởi hành: <strong><?php echo date('d/m/Y', strtotime($item['NgayKhoiHanh'])); ?></strong>
                        </p>
                        <p style="font-size:13px; color:#666;">
                            <i class="fas fa-users"></i> <?php echo $item['SoNguoiLon']; ?> Người lớn, <?php echo $item['SoTreEm']; ?> Trẻ em
                        </p>
                    </div>

                    <div style="text-align:right;">
                        <div style="font-size:18px; font-weight:bold; color:var(--primary-color); margin-bottom:5px;">
                            <?php echo number_format($item['TongGia'], 0, ',', '.'); ?>đ
                        </div>
                        
                        <?php 
                            $statusColor = '#f39c12'; // Vàng (Chờ xử lý)
                            if($item['TrangThai'] == 'Đã xác nhận') $statusColor = '#2ecc71'; // Xanh (OK)
                            if($item['TrangThai'] == 'Đã hủy') $statusColor = '#e74c3c'; // Đỏ (Hủy)
                        ?>
                        <span style="background:<?php echo $statusColor; ?>; color:white; padding:4px 10px; border-radius:20px; font-size:12px; font-weight:600;">
                            <?php echo $item['TrangThai']; ?>
                        </span>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-center">Bạn chưa đặt tour nào. <a href="index.php" style="color:var(--primary-color);">Khám phá ngay!</a></p>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>