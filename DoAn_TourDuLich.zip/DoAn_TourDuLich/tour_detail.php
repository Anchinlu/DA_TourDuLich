<?php 
include 'includes/header.php'; 
require_once 'config/db_connect.php';

// 1. LẤY ID TOUR TỪ URL
if (!isset($_GET['id'])) {
    echo "<script>alert('Không tìm thấy tour!'); window.location='index.php';</script>";
    exit;
}
$tour_id = $_GET['id'];

// 2. TRUY VẤN DỮ LIỆU TOUR
try {
    // Lấy thông tin tour + tên danh mục
    $sql = "SELECT t.*, d.TenDanhMuc 
            FROM Tour t 
            LEFT JOIN DanhMuc d ON t.idDanhMuc = d.id 
            WHERE t.id = ?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$tour_id]);
    $tour = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$tour) {
        echo "<script>alert('Tour không tồn tại!'); window.location='index.php';</script>";
        exit;
    }
} catch (Exception $e) {
    echo "Lỗi: " . $e->getMessage();
}
?>

<div class="breadcrumb">
    <div class="container">
        <a href="index.php">Trang chủ</a> <span>/</span> 
        <a href="#"><?php echo htmlspecialchars($tour['TenDanhMuc']); ?></a> <span>/</span> 
        <?php echo htmlspecialchars($tour['TenTour']); ?>
    </div>
</div>

<section class="section-padding" style="padding-top: 20px;">
    <div class="container">
        
        <div class="tour-header">
            <h1 class="tour-title"><?php echo htmlspecialchars($tour['TenTour']); ?></h1>
            <div class="tour-meta">
                <span><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($tour['TenDanhMuc']); ?></span>
                <span><i class="far fa-clock"></i> 3 Ngày 2 Đêm</span> <span><i class="fas fa-star" style="color:orange"></i> 4.8 (120 đánh giá)</span>
            </div>
        </div>

        <div class="tour-layout">
            <div class="tour-content">
                <img src="<?php echo !empty($tour['HinhAnh']) ? $tour['HinhAnh'] : 'assets/images/default-tour.jpg'; ?>" class="tour-image-main">
                
                <div class="content-block">
                    <h3 class="content-title">Giới thiệu</h3>
                    <div class="content-text">
                        <?php echo nl2br(htmlspecialchars($tour['MoTa'])); ?>
                    </div>
                </div>

                <div class="content-block">
                    <h3 class="content-title">Lịch trình (Tham khảo)</h3>
                    <div class="content-text">
                        <p><strong>Ngày 1:</strong> Đón khách - Tham quan địa điểm A - Ăn trưa...</p>
                        <p><strong>Ngày 2:</strong> Leo núi - Cắm trại - Tiệc nướng BBQ...</p>
                        <p><strong>Ngày 3:</strong> Mua sắm - Tiễn sân bay.</p>
                        <i style="color:#999;">(Dữ liệu lịch trình chi tiết sẽ được cập nhật sau từ Admin)</i>
                    </div>
                </div>
            </div>

            <div class="tour-sidebar">
                <div class="booking-box">
                    <div class="price-tag">
                        <?php echo number_format($tour['Gia'], 0, ',', '.'); ?>đ <span>/ khách</span>
                    </div>

                    <form action="booking_process.php" method="POST" class="booking-form">
                        <input type="hidden" name="tour_id" value="<?php echo $tour['id']; ?>">
                        <input type="hidden" id="tour_price" value="<?php echo $tour['Gia']; ?>">

                        <div class="form-group">
                            <label><i class="far fa-calendar-alt"></i> Ngày khởi hành:</label>
                            <input type="date" name="start_date" required min="<?php echo date('Y-m-d'); ?>">
                        </div>

                        <div class="form-group">
                            <label><i class="fas fa-user-friends"></i> Người lớn:</label>
                            <input type="number" name="adults" id="adults" value="1" min="1" onchange="calcTotal()">
                        </div>

                        <div class="form-group">
                            <label><i class="fas fa-child"></i> Trẻ em (50%):</label>
                            <input type="number" name="children" id="children" value="0" min="0" onchange="calcTotal()">
                        </div>

                        <div class="total-price">
                            <span>Tổng cộng:</span>
                            <span id="total_display" style="color:var(--primary-color)">
                                <?php echo number_format($tour['Gia'], 0, ',', '.'); ?>đ
                            </span>
                        </div>

                        <div style="margin-top: 20px;">
                            <?php if (isset($_SESSION['user_id'])): ?>
                                <button type="submit" class="btn-primary" style="width:100%">ĐẶT TOUR NGAY</button>
                            <?php else: ?>
                                <a href="login.php" class="btn-primary" style="display:block; text-align:center; background:#666;">
                                    Đăng nhập để đặt
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</section>

<script>
function calcTotal() {
    const price = parseInt(document.getElementById('tour_price').value);
    const adults = parseInt(document.getElementById('adults').value) || 0;
    const children = parseInt(document.getElementById('children').value) || 0;

    // Trẻ em tính 50% giá (Ví dụ)
    const total = (price * adults) + (price * 0.5 * children);

    // Format tiền tệ (VNĐ)
    const formatted = new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(total);
    
    document.getElementById('total_display').innerText = formatted;
}
</script>

<?php include 'includes/footer.php'; ?>0
